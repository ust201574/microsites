test.js   ---> src/pages --- new file

form.json ---> src/data --- updated file
routes.js ---> src/components -- updated file
my-form.js ---> src/components -- updated file
